## How to use
* Download as zip
* unzip zip
* move python file to any location on your pc
* File only returns values
---

### __.\ v1.0\\\\__

* Max amount of roots: 8
* Very easy to use.

### __.\ v1.0.1\\\\__
* Max amount of roots: 15

### __.\ v1.0.2\\\\__
* Added Class roots to store all root functions

### __.\ v1.0.3\\\\__
* Added Power Function
    * Power Function takes in an ```expression```, and a ```power``` argument
---

use [github wiki](https://github.com/CaidynPaul/cmathlib/wiki) or Join the [Discord](https://discord.gg/5sAd4mQvRZ) If you have any Questions