from music import *

# This will play the A Major Chord
play(0,'A3',1)
play(1,'Db4',1)
play(2,'E4',1)

wait()
