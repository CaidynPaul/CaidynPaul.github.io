# UberTTT
A collaborative project of tictactoe

## Developers

`Yusuf Sajjad` and `Caidyn Paul`

# About

This project includes a fully functioning GUI and a AI system.
This project is __HW__.

# Other Projects
[Jukebox](https://github.com/CaidynPaul/PyJukeBox)

[Music.py](https://github.com/CaidynPaul/music.py)
